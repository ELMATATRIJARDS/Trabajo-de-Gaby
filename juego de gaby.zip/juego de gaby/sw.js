const CACHE_NAME = 'ruleta-cache-v3'; // Nombre del cache
const FILES_TO_CACHE = [               
  './index.html',      // Archivo HTML principal
  './manifest.json',   // Manifiesto de la PWA
  './ruleta.jpg',        
  './script.js',       // Script principal
];

// Evento de instalación: Se ejecuta cuando el Service Worker se instala
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => {
      return cache.addAll(FILES_TO_CACHE);  // Guardar los archivos en caché
    })
  );
});

// Evento de activación: Se ejecuta cuando el Service Worker se activa
self.addEventListener('activate', (event) => {
  const cacheWhitelist = [CACHE_NAME];  // Solo mantener el caché actual
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (!cacheWhitelist.includes(cacheName)) {
            return caches.delete(cacheName);  // Eliminar cachés antiguos
          }
        })
      );
    })
  );
});

// Evento de fetch: Intercepta las peticiones de red y sirve desde el caché si es posible
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      // Si hay una respuesta en caché, se usa; si no, se hace la petición de red
      return cachedResponse || fetch(event.request).then((networkResponse) => {
        // Después de hacer la petición, guardamos el recurso en caché
        if (event.request.url.startsWith(self.location.origin)) {  // Asegura que solo se cacheen recursos de tu dominio
          caches.open(CACHE_NAME).then((cache) => {
            cache.put(event.request, networkResponse.clone());  // Guardamos la respuesta en caché para futuras peticiones
          });
        }
        return networkResponse;
      });
    })
  );
});
